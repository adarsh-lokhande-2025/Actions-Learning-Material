public class HelloActions {
  public static void main(String[] args) {
    System.out.println("Hello, GitHub Actions!");
  }
}
